package org.example;

public interface JdbcInstall {
    public String install();
}
