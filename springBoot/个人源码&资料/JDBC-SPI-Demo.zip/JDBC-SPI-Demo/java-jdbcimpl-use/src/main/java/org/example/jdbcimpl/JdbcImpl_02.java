package org.example.jdbcimpl;

import org.example.JdbcInstall;

public class JdbcImpl_02 implements JdbcInstall {

    @Override
    public String install() {
        return "Oracle驱动安装成功！！！";
    }
}
