package org.example.jdbcimpl;

import org.example.JdbcInstall;

public class JdbcImpl_03 implements JdbcInstall {

    @Override
    public String install() {
        return "SQL server驱动安装成功！！！";
    }
}
