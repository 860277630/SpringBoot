package org.example.jdbcimpl;

import org.example.JdbcInstall;

public class JdbcImpl_01 implements JdbcInstall {

    @Override
    public String install() {
        return "MySQL驱动安装成功！！！";
    }
}
