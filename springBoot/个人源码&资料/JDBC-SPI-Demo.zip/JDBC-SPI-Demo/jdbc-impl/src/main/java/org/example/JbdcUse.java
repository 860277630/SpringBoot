package org.example;

import sun.misc.Service;

import java.util.Iterator;
import java.util.ServiceLoader;

public class JbdcUse {
    public static void main(String[] args) {
        Iterator<JdbcInstall> providers = Service.providers(JdbcInstall.class);
        ServiceLoader<JdbcInstall> load = ServiceLoader.load(JdbcInstall.class);
        while(providers.hasNext()) {
            JdbcInstall ser = providers.next();
            System.out.println(ser.install());
        }
        System.out.println("--------------------------------");
        Iterator<JdbcInstall> iterator = load.iterator();
        while(iterator.hasNext()) {
            JdbcInstall ser = iterator.next();
            System.out.println(ser.install());
        }
    }
}
